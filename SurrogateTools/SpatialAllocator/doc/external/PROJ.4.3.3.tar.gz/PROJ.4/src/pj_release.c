/* <<< Release Notice for library >>> */
#ifndef lint
static const char SCCSID[]="@(#)pj_release.c	4.5 95/09/23 GIE REL";
#endif

char const pj_release[]="Rel. 4.3.3, 23 Sept. 1995";
