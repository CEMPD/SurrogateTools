/* For full ANSI compliance of global variable */
#ifndef lint
static const char SCCSID[]="@(#)pj_errno.c	4.3	95/06/03	GIE	REL";
#endif

int pj_errno = 0;

/* end */
